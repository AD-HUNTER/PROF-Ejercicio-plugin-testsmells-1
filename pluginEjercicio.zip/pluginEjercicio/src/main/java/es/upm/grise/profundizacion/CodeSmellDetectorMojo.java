package es.upm.grise.profundizacion;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import testsmell.AbstractSmell;
import testsmell.TestFile;
import testsmell.TestSmellDetector;
import thresholds.SpadiniThresholds;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

@Mojo(name = "detect-smells", defaultPhase = LifecyclePhase.TEST)
public class CodeSmellDetectorMojo extends AbstractMojo {

    @Parameter(defaultValue = "${project.basedir}", readonly = true, required = true)
    private File baseDir;

    @Override
    public void execute() throws MojoExecutionException {
        File testDir = new File(baseDir, "src/test/java");

        if (!testDir.exists() || !testDir.isDirectory()) {
            getLog().warn("No se ha encontrado el directorio de tests: " + testDir.getAbsolutePath());
            return;
        }

        getLog().info("Detectando test smells en: " + testDir.getAbsolutePath());

        List<String> smells = detectSmells(testDir);

        getLog().info("\n=== Test Smells detectados ===");
        for (String smell : smells) {
            getLog().warn(smell);
        }

        if (!smells.isEmpty()) {
            getLog().info("Total de smells detectados: " + smells.size());
        }
    }

    private List<String> detectSmells(File directory) throws MojoExecutionException {
        List<String> smells = new ArrayList<>();

        String app = baseDir.getName();

        // Usar directamente los thresholds ya implementados en el jar
        TestSmellDetector detector = new TestSmellDetector(new SpadiniThresholds());

        try {
            Files.walk(directory.toPath())
                    .filter(path -> path.toString().endsWith(".java"))
                    .forEach(path -> {
                        File testFileOnDisk = path.toFile();
                        String testAbsolutePath = testFileOnDisk.getAbsolutePath();
                        String fileName = testFileOnDisk.getName();

                        try {
                            String productionFilePath = getProductionFilePathFromTest(testFileOnDisk);

                            if (productionFilePath == null) {
                                getLog().warn("No se ha encontrado el fichero de producción para el test: " + testAbsolutePath);
                                return;
                            }

                            TestFile testFile = new TestFile(app, testAbsolutePath, productionFilePath);
                            TestFile detectionResult = detector.detectSmells(testFile);

                            for (AbstractSmell smell : detectionResult.getTestSmells()) {
                                if (smell != null && smell.hasSmell()) {
                                    smells.add(fileName + ": " + smell.getSmellName());
                                }
                            }

                        } catch (Exception e) {
                            getLog().error("Error detectando smells en " + fileName, e);
                        }
                    });
        } catch (IOException e) {
            throw new MojoExecutionException("Error recorriendo el directorio de tests", e);
        }

        return smells;
    }

    private String getProductionFilePathFromTest(File testFile) {
        String testPath = testFile.getAbsolutePath();

        String mainPath = testPath.replace(File.separator + "src" + File.separator + "test" + File.separator + "java",
                File.separator + "src" + File.separator + "main" + File.separator + "java");

        if (mainPath.endsWith("Test.java")) {
            mainPath = mainPath.substring(0, mainPath.length() - "Test.java".length()) + ".java";
        }

        File productionFile = new File(mainPath);
        if (!productionFile.exists()) {
            return null;
        }

        return productionFile.getAbsolutePath();
    }
}
