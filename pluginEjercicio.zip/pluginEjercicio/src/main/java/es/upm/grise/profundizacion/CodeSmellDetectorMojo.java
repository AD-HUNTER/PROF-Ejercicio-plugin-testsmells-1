package es.upm.grise.profundizacion;

import testsmell.TestSmellDetector;
import testsmell.TestFile;
import testsmell.AbstractSmell;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.LifecyclePhase;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

@Mojo(name = "detect-smells", defaultPhase = LifecyclePhase.TEST)
public class CodeSmellDetectorMojo extends AbstractMojo {

    @Parameter(defaultValue = "${project.build.testSourceDirectory}", readonly = true)
    private File sourceDirectory;

    public void execute() throws MojoExecutionException {
        getLog().info("Detectando test smells en: " + sourceDirectory);

        List<String> smells = detectSmells(sourceDirectory);

        getLog().info("\n=== Test Smells Detectados ===");
        for (String smell : smells) {
            getLog().warn(smell);
        }

        if (!smells.isEmpty()) {
            getLog().info("Total de smells detectados: " + smells.size());
            // Si quieres fallar la build al detectar smells:
            // throw new MojoExecutionException("Se han detectado test smells.");
        }
    }

    private List<String> detectSmells(File directory) throws MojoExecutionException {
        List<String> smells = new ArrayList<>();

        try {
            Files.walk(directory.toPath())
                    .filter(path -> path.toString().endsWith(".java"))
                    .forEach(path -> {
                        try {
                            String code = Files.readString(path);

                            List<String> detectedSmells =
                                    detectSmellsWithTsDetect(code, path.toFile().getAbsolutePath(), path.getFileName().toString());

                            smells.addAll(detectedSmells);
                        } catch (IOException e) {
                            getLog().error("Error analizando archivo: " + path, e);
                        }
                    });
        } catch (IOException e) {
            throw new MojoExecutionException("Error al recorrer directorio de fuentes", e);
        }

        return smells;
    }

    private List<String> detectSmellsWithTsDetect(String code, String absolutePath, String fileName) {
        List<String> smells = new ArrayList<>();
        try {
            TestFile testFile = new TestFile(absolutePath, fileName, code);

            TestSmellDetector detector = new TestSmellDetector(null); // mejor que null

            var detectionResult = detector.detectSmells(testFile);

            for (AbstractSmell smell : detectionResult.getTestSmells()) {
                smells.add(fileName + ": " + smell.getClass().getSimpleName());
            }

        } catch (Exception e) {
            getLog().error("Error detectando smells en " + fileName + ": " + e.getMessage(), e);
        }
        return smells;
    }
}
